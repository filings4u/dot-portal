# Owner-Operator Portal Control Wiring

DOT Management now has a dedicated Owner-Operator control workspace at:

- `dot-owner-operator-detail.html?id=<owner_operator_id>`

The Owner-Operator directory's **Manage Portal** button opens this workspace.

## Page mapping

| Owner-Operator page | Authoritative records | DOT Management control |
|---|---|---|
| Getting Started / Onboarding | `owner_operators.metadata`, `owner_operator_consortium_agreements`, `dot_documents`, `ctpa_dot_testing_requests` | Status/audit review; company corrections are admin-only without rewriting signed agreements |
| Clearinghouse Setup | `owner_operator_clearinghouse_designations` | Confirm/restore or revoke designation |
| Dashboard | Shared operational tables below | Live aggregate |
| Company Profile | `owner_operators`, `employers`, `organizations` | Administrative correction updates all synchronized records |
| Driver | `employees` | Existing DOT driver management + owner-scoped view |
| DOT Program | `programs` | Create/manage owner-scoped DOT programs |
| Consortium / Random Pool | `random_pools`, `pool_memberships` | Create owner pool and enroll driver |
| Testing | `testing_orders` | Existing DOT testing management |
| Results | `test_results`, result reports | Existing DOT result management |
| Compliance | `dot_compliance_cases` | Existing DOT compliance management |
| Return-to-Duty | `sap_cases`, compliance records | Existing DOT RTD/SAP management |
| Documents | `dot_documents` | Existing DOT document management |
| Reports | Testing, compliance, documents | Derived from shared records |
| Support | `support_tickets`, `support_ticket_messages` | Existing DOT support management |
| Billing | `subscriptions`, `dot_invoices` | Existing DOT billing management |
| Notifications | `dot_notifications` | Existing DOT notification management |
| Audit | `audit_events` | Existing DOT audit history |

## Backend additions

`dot-enterprise-management` now supports:

- `owner_operator_detail`
- `save_owner_operator_profile_admin`
- `save_owner_operator_clearinghouse_admin`

These actions use the same Supabase records consumed by the Owner-Operator portal rather than a duplicate management-only data model.
